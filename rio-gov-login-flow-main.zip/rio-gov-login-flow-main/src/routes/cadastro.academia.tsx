import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Building2, MapPin, Map, Hash, Briefcase, Phone, Clock } from "lucide-react";
import logoAsset from "@/assets/logo-social-pass.png.asset.json";
import cristoAsset from "@/assets/cristo-redentor.png.asset.json";

export const Route = createFileRoute("/cadastro/academia")({
  component: CadastroAcademia,
  head: () => ({
    meta: [
      { title: "Cadastro de Academia | Social Pass" },
      { name: "description", content: "Cadastre sua academia como parceira do Social Pass." },
    ],
  }),
});

const ATIVIDADES = ["Musculação", "Funcional", "Ginástica", "Natação", "Crossfit", "Pilates", "Dança", "Lutas"];

const formatCep = (v: string) => v.replace(/\D/g, "").slice(0, 8).replace(/(\d{5})(\d)/, "$1-$2");
const formatCnpj = (v: string) =>
  v.replace(/\D/g, "").slice(0, 14)
    .replace(/(\d{2})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1/$2")
    .replace(/(\d{4})(\d{1,2})$/, "$1-$2");
const formatPhone = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 10) return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
};

function CadastroAcademia() {
  const [form, setForm] = useState({
    nome: "", endereco: "", bairro: "", cep: "", cnpj: "", telefone: "", horario: "",
    vestiario: "sim" as "sim" | "nao",
    ativa: "ativa" as "ativa" | "inativa",
  });
  const [atividades, setAtividades] = useState<string[]>([]);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((s) => ({ ...s, [k]: e.target.value }));

  const toggle = (a: string) =>
    setAtividades((prev) => prev.includes(a) ? prev.filter((x) => x !== a) : [...prev, a]);

  return (
    <div className="min-h-screen bg-[image:var(--gradient-panel)] relative overflow-hidden">
      <img
        src={cristoAsset.url}
        alt=""
        aria-hidden
        className="pointer-events-none select-none absolute -right-20 top-1/2 -translate-y-1/2 w-[720px] max-w-none opacity-[0.06]"
      />

      <header className="relative z-10 bg-[var(--brand-navy)] text-white">
        <div className="max-w-[1100px] mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <img src={logoAsset.url} alt="Social Pass" className="h-8 w-8 object-contain" />
            <span className="font-display font-bold tracking-[0.2em] text-sm uppercase">
              Assistência Social
            </span>
          </Link>
          <Link to="/" className="text-xs flex items-center gap-1.5 text-white/80 hover:text-white transition">
            <ArrowLeft className="h-4 w-4" /> Voltar
          </Link>
        </div>
      </header>

      <main className="relative z-10 max-w-3xl mx-auto px-6 py-10">
        <div className="mb-8 text-center">
          <img src={logoAsset.url} alt="" className="h-14 w-14 mx-auto mb-3 object-contain" />
          <span className="inline-block text-xs font-semibold tracking-[0.22em] text-[var(--brand-blue)] uppercase">
            Rede de Parceiros
          </span>
          <h1 className="font-display font-extrabold text-4xl md:text-5xl text-[var(--brand-navy)] mt-2">
            Cadastro de Academia
          </h1>
          <p className="text-muted-foreground mt-2 text-sm">
            Torne-se uma unidade parceira do Social Pass da Prefeitura do Rio.
          </p>
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); }}
          className="bg-white rounded-2xl border border-border shadow-[var(--shadow-soft)] p-6 md:p-8 space-y-5"
        >
          <Field label="Nome da Academia" icon={<Building2 className="h-4 w-4" />}>
            <input required value={form.nome} onChange={set("nome")}
              placeholder="Ex: Academia Popular Flamengo" className={inputCls} />
          </Field>

          <div className="grid md:grid-cols-[1fr_260px] gap-5">
            <Field label="Endereço" icon={<MapPin className="h-4 w-4" />}>
              <input required value={form.endereco} onChange={set("endereco")}
                placeholder="Rua, número" className={inputCls} />
            </Field>
            <Field label="Bairro" icon={<Map className="h-4 w-4" />}>
              <input required value={form.bairro} onChange={set("bairro")}
                placeholder="Ex: Tijuca" className={inputCls} />
            </Field>
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            <Field label="CEP" icon={<Hash className="h-4 w-4" />}>
              <input required inputMode="numeric" value={form.cep}
                onChange={(e) => setForm((s) => ({ ...s, cep: formatCep(e.target.value) }))}
                placeholder="00000-000" className={inputCls} />
            </Field>
            <Field label="CNPJ" icon={<Briefcase className="h-4 w-4" />}>
              <input required inputMode="numeric" value={form.cnpj}
                onChange={(e) => setForm((s) => ({ ...s, cnpj: formatCnpj(e.target.value) }))}
                placeholder="00.000.000/0000-00" className={inputCls} />
            </Field>
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            <Field label="Telefone" icon={<Phone className="h-4 w-4" />}>
              <input required inputMode="tel" value={form.telefone}
                onChange={(e) => setForm((s) => ({ ...s, telefone: formatPhone(e.target.value) }))}
                placeholder="(21) 99999-9999" className={inputCls} />
            </Field>
            <Field label="Horário de Funcionamento" icon={<Clock className="h-4 w-4" />}>
              <input required value={form.horario} onChange={set("horario")}
                placeholder="Seg a Sex, 6h às 22h" className={inputCls} />
            </Field>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[var(--brand-navy)] mb-3 tracking-wide uppercase">
              Tipos de Atividade
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {ATIVIDADES.map((a) => {
                const active = atividades.includes(a);
                return (
                  <button
                    key={a}
                    type="button"
                    onClick={() => toggle(a)}
                    className={`h-10 px-3 rounded-lg text-sm font-medium border transition-all ${
                      active
                        ? "bg-[var(--brand-navy)] text-white border-[var(--brand-navy)]"
                        : "bg-white text-[var(--brand-navy)] border-border hover:border-[var(--brand-blue)]"
                    }`}
                  >
                    {a}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-[var(--brand-navy)] mb-3 tracking-wide uppercase">
                Possui Vestiário?
              </label>
              <div className="flex gap-4">
                {(["sim", "nao"] as const).map((v) => (
                  <label key={v} className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="vestiario" value={v} checked={form.vestiario === v}
                      onChange={() => setForm((s) => ({ ...s, vestiario: v }))}
                      className="h-4 w-4 accent-[var(--brand-navy)]" />
                    <span className="text-sm text-[var(--brand-navy)] capitalize">{v === "sim" ? "Sim" : "Não"}</span>
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[var(--brand-navy)] mb-3 tracking-wide uppercase">
                Status
              </label>
              <select value={form.ativa}
                onChange={(e) => setForm((s) => ({ ...s, ativa: e.target.value as "ativa" | "inativa" }))}
                className="w-full h-11 px-3 rounded-xl bg-white border border-border text-[var(--brand-navy)] focus:outline-none focus:border-[var(--brand-blue)] focus:ring-4 focus:ring-[var(--brand-blue)]/15">
                <option value="ativa">Ativa</option>
                <option value="inativa">Inativa</option>
              </select>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Link to="/" className="flex-1 h-12 rounded-xl border-2 border-[var(--brand-navy)] text-[var(--brand-navy)] font-display font-bold tracking-wider text-sm uppercase flex items-center justify-center hover:bg-secondary transition">
              Cancelar
            </Link>
            <button type="submit"
              className="flex-1 h-12 rounded-xl bg-[var(--brand-navy)] text-white font-display font-bold tracking-wider text-sm uppercase shadow-[var(--shadow-elegant)] hover:bg-[var(--brand-blue)] transition">
              Cadastrar Academia
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}

const inputCls =
  "w-full h-12 pl-11 pr-4 rounded-xl bg-white border border-border text-[var(--brand-navy)] placeholder:text-muted-foreground focus:outline-none focus:border-[var(--brand-blue)] focus:ring-4 focus:ring-[var(--brand-blue)]/15 transition-all";

function Field({ label, icon, children }: { label: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-[var(--brand-navy)] mb-2 tracking-wide uppercase">
        {label}
      </label>
      <div className="relative">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</span>
        {children}
      </div>
    </div>
  );
}
