import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff, Lock, User, Waves, Mountain, UserPlus, Building2 } from "lucide-react";
import logoAsset from "@/assets/logo-social-pass.png.asset.json";
import cristoAsset from "@/assets/cristo-redentor.png.asset.json";
import rioHeroAsset from "@/assets/rio-hero.png.asset.json";

export const Route = createFileRoute("/")({
  component: LoginPage,
});

function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [mode, setMode] = useState<"usuario" | "academia">("usuario");
  const [cpf, setCpf] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [password, setPassword] = useState("");

  const formatCpf = (v: string) => {
    const digits = v.replace(/\D/g, "").slice(0, 11);
    return digits
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
  };

  const formatCnpj = (v: string) => {
    const digits = v.replace(/\D/g, "").slice(0, 14);
    return digits
      .replace(/^(\d{2})(\d)/, "$1.$2")
      .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
      .replace(/\.(\d{3})(\d)/, ".$1/$2")
      .replace(/(\d{4})(\d{1,2})$/, "$1-$2");
  };

  const isAcademia = mode === "academia";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top bar */}
      <header className="w-full bg-white border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 h-20 flex items-center justify-between">
          <a href="/" className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-white flex items-center justify-center">
              <img src={logoAsset.url} alt="Social Pass" className="h-10 w-10 object-contain" width={40} height={40} />
            </div>
            <div className="hidden sm:flex flex-col leading-tight border-l border-border pl-3">
              <span className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase">
                Prefeitura do Rio
              </span>
              <span className="text-sm font-bold text-[var(--brand-navy)] uppercase tracking-wide">
                Assistência Social
              </span>
            </div>
          </a>
          <div className="flex items-center gap-2">
            <img src={logoAsset.url} alt="" className="h-6 w-6 object-contain sm:hidden" width={24} height={24} />
            <span className="font-display font-bold tracking-[0.18em] text-sm uppercase text-[var(--brand-navy)]">
              Social Pass
            </span>
          </div>
        </div>
      </header>

      {/* Main split */}
      <main className="flex-1 grid lg:grid-cols-[minmax(0,1fr)_1.1fr]">
        {/* Left — form */}
        <section className="relative flex items-center justify-center px-6 py-14 lg:px-16 bg-[image:var(--gradient-panel)] overflow-hidden">
          <img
            src={cristoAsset.url}
            alt=""
            aria-hidden
            className="lg:hidden pointer-events-none select-none absolute -right-16 top-1/2 -translate-y-1/2 w-[520px] max-w-none opacity-[0.07]"
          />
          <div className="relative w-full max-w-md">
            <div className="mb-10">
              <div className="flex items-center gap-3 mb-6 lg:hidden">
                <img src={logoAsset.url} alt="Social Pass" className="h-12 w-12 object-contain" width={48} height={48} />
                <span className="font-display font-bold text-2xl text-[var(--brand-navy)]">Social Pass</span>
              </div>
              <span className="inline-block text-xs font-semibold tracking-[0.22em] text-[var(--brand-blue)] uppercase mb-3">
                Portal do Cidadão Carioca
              </span>
              <h1 className="font-display font-extrabold text-6xl md:text-7xl text-[var(--brand-sky)] leading-none tracking-tight">
                LOGIN
              </h1>
              <p className="mt-5 text-[var(--brand-navy)] text-base leading-relaxed">
                Olá, carioca! Informe seus dados abaixo para acessar seu social pass.
              </p>
            </div>

            <div className="mb-5 grid grid-cols-2 gap-1 p-1 rounded-xl bg-white border border-border">
              <button
                type="button"
                onClick={() => setMode("usuario")}
                className={`h-11 rounded-lg text-xs font-display font-bold tracking-[0.15em] uppercase flex items-center justify-center gap-2 transition-all ${
                  !isAcademia
                    ? "bg-[var(--brand-navy)] text-white shadow-sm"
                    : "text-[var(--brand-navy)] hover:bg-secondary"
                }`}
              >
                <User className="h-4 w-4" /> Usuário
              </button>
              <button
                type="button"
                onClick={() => setMode("academia")}
                className={`h-11 rounded-lg text-xs font-display font-bold tracking-[0.15em] uppercase flex items-center justify-center gap-2 transition-all ${
                  isAcademia
                    ? "bg-[var(--brand-blue)] text-white shadow-sm"
                    : "text-[var(--brand-navy)] hover:bg-secondary"
                }`}
              >
                <Building2 className="h-4 w-4" /> Academia
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="identifier" className="block text-xs font-semibold text-[var(--brand-navy)] mb-2 tracking-wide uppercase">
                  {isAcademia ? "CNPJ" : "CPF"}
                </label>
                <div className="relative">
                  {isAcademia ? (
                    <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  ) : (
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  )}
                  {isAcademia ? (
                    <input
                      id="identifier"
                      type="text"
                      inputMode="numeric"
                      autoComplete="username"
                      placeholder="00.000.000/0000-00"
                      value={cnpj}
                      onChange={(e) => setCnpj(formatCnpj(e.target.value))}
                      className="w-full h-14 pl-11 pr-4 rounded-xl bg-white border border-border text-[var(--brand-navy)] placeholder:text-muted-foreground focus:outline-none focus:border-[var(--brand-blue)] focus:ring-4 focus:ring-[var(--brand-blue)]/15 transition-all"
                    />
                  ) : (
                    <input
                      id="identifier"
                      type="text"
                      inputMode="numeric"
                      autoComplete="username"
                      placeholder="000.000.000-00"
                      value={cpf}
                      onChange={(e) => setCpf(formatCpf(e.target.value))}
                      className="w-full h-14 pl-11 pr-4 rounded-xl bg-white border border-border text-[var(--brand-navy)] placeholder:text-muted-foreground focus:outline-none focus:border-[var(--brand-blue)] focus:ring-4 focus:ring-[var(--brand-blue)]/15 transition-all"
                    />
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-xs font-semibold text-[var(--brand-navy)] mb-2 tracking-wide uppercase">
                  Senha
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    placeholder="Digite sua senha"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full h-14 pl-11 pr-12 rounded-xl bg-white border border-border text-[var(--brand-navy)] placeholder:text-muted-foreground focus:outline-none focus:border-[var(--brand-blue)] focus:ring-4 focus:ring-[var(--brand-blue)]/15 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-lg text-muted-foreground hover:text-[var(--brand-navy)] hover:bg-secondary transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm pt-1">
                <label className="flex items-center gap-2 text-[var(--brand-navy)] cursor-pointer select-none">
                  <input type="checkbox" className="h-4 w-4 rounded border-border text-[var(--brand-blue)] focus:ring-[var(--brand-blue)]" />
                  <span>Lembrar de mim</span>
                </label>
                <a href="#" className="text-[var(--brand-blue)] font-medium hover:underline underline-offset-4">
                  Esqueceu a senha?
                </a>
              </div>

              <button
                type="submit"
                className={`w-full h-14 mt-4 rounded-xl text-white font-display font-bold tracking-[0.15em] text-sm uppercase shadow-[var(--shadow-elegant)] hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 ${
                  isAcademia
                    ? "bg-[var(--brand-blue)] hover:bg-[var(--brand-navy)]"
                    : "bg-[var(--brand-navy)] hover:bg-[var(--brand-blue)]"
                }`}
              >
                {isAcademia ? "Entrar como Academia" : "Entrar"}
              </button>

              <div className="relative py-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center">
                  <span className="bg-[oklch(0.98_0.008_240)] px-3 text-xs uppercase tracking-widest text-muted-foreground">
                    ou
                  </span>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <Link
                  to="/cadastro/usuario"
                  className="h-14 rounded-xl border-2 border-[var(--brand-navy)] text-[var(--brand-navy)] font-display font-bold tracking-wider text-xs uppercase flex items-center justify-center gap-2 hover:bg-[var(--brand-navy)] hover:text-white transition-all"
                >
                  <UserPlus className="h-4 w-4" /> Cadastrar Usuário
                </Link>
                <Link
                  to="/cadastro/academia"
                  className="h-14 rounded-xl border-2 border-[var(--brand-blue)] text-[var(--brand-blue)] font-display font-bold tracking-wider text-xs uppercase flex items-center justify-center gap-2 hover:bg-[var(--brand-blue)] hover:text-white transition-all"
                >
                  <Building2 className="h-4 w-4" /> Cadastrar Academia
                </Link>
              </div>
            </form>

            <p className="mt-8 text-xs text-muted-foreground text-center leading-relaxed">
              Ao continuar, você concorda com os{" "}
              <a href="#" className="underline underline-offset-2 hover:text-[var(--brand-navy)]">termos de uso</a>{" "}
              e a{" "}
              <a href="#" className="underline underline-offset-2 hover:text-[var(--brand-navy)]">política de privacidade</a>{" "}
              da Prefeitura do Rio.
            </p>
          </div>
        </section>

        {/* Right — Rio-themed hero visual */}
        <section className="relative hidden lg:flex overflow-hidden bg-gradient-to-br from-[var(--brand-blue)] via-[var(--brand-navy)] to-[oklch(0.2_0.09_260)]">

          {/* Soft cloud/mist */}
          <div aria-hidden className="absolute top-32 left-20 h-40 w-72 rounded-full bg-white/5 blur-3xl" />
          <div aria-hidden className="absolute top-52 right-48 h-32 w-56 rounded-full bg-[var(--brand-sky)]/20 blur-3xl" />

          {/* Rio de Janeiro hero illustration - centerpiece */}
          <div className="relative z-10 flex items-center justify-center w-full h-full">
            <div className="relative">
              {/* Soft glow behind the illustration */}
              <div aria-hidden className="absolute inset-0 bg-[var(--brand-sky)]/20 blur-3xl scale-110" />
              <img
                src={rioHeroAsset.url}
                alt="Ilustração do Rio de Janeiro: Cristo Redentor, Pão de Açúcar e calçadão de Copacabana"
                className="relative w-[680px] max-w-[88%] mx-auto rounded-2xl border border-white/10 shadow-[0_30px_60px_rgba(0,0,0,0.4)]"
                width={1024}
                height={1024}
              />
            </div>
          </div>

          {/* Wave decoration at bottom (Copacabana calçadão vibe) */}
          <svg
            aria-hidden
            className="absolute bottom-0 left-0 right-0 w-full text-white/10"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              d="M0,60 C150,100 300,20 450,60 C600,100 750,20 900,60 C1050,100 1200,40 1200,60 L1200,120 L0,120 Z"
              fill="currentColor"
            />
            <path
              d="M0,80 C150,110 300,50 450,80 C600,110 750,50 900,80 C1050,110 1200,60 1200,80 L1200,120 L0,120 Z"
              fill="currentColor"
              opacity="0.5"
            />
          </svg>

          {/* Bottom overlay text */}
          <div className="absolute bottom-0 left-0 right-0 z-20 px-12 pb-10 pt-24 bg-gradient-to-t from-[var(--brand-navy)] via-[var(--brand-navy)]/70 to-transparent">
            <div className="flex items-center gap-2 mb-3 text-[var(--brand-yellow)]">
              <Mountain className="h-4 w-4" />
              <Waves className="h-4 w-4" />
              <span className="text-xs tracking-[0.22em] font-semibold uppercase">Cidade Maravilhosa</span>
            </div>
            <p className="font-display font-bold text-white text-3xl leading-tight max-w-lg">
              Do Cristo à Praia, cuidando de cada carioca.
            </p>
            <p className="mt-3 text-white/75 text-sm tracking-wide max-w-md">
              Social Pass · Programa da Secretaria de Assistência Social do Rio de Janeiro.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-[var(--brand-navy)] text-white/80 text-center text-xs py-4 tracking-wide">
        © {new Date().getFullYear()} Prefeitura da Cidade do Rio de Janeiro · Secretaria de Assistência Social
      </footer>
    </div>
  );
}
