import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, User, IdCard, Calendar, Mail, Phone, Lock, Eye, EyeOff } from "lucide-react";
import logoAsset from "@/assets/logo-social-pass.png.asset.json";
import cristoAsset from "@/assets/cristo-redentor.png.asset.json";

export const Route = createFileRoute("/cadastro/usuario")({
  component: CadastroUsuario,
  head: () => ({
    meta: [
      { title: "Cadastro de Usuário | Social Pass" },
      { name: "description", content: "Crie sua conta no Social Pass da Prefeitura do Rio." },
    ],
  }),
});

const formatCpf = (v: string) =>
  v.replace(/\D/g, "").slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");

const formatPhone = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 10) return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
};

function CadastroUsuario() {
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    nome: "", cpf: "", nascimento: "", email: "", telefone: "", senha: "",
  });
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((s) => ({ ...s, [k]: e.target.value }));

  return (
    <div className="min-h-screen bg-[image:var(--gradient-panel)] relative overflow-hidden">
      {/* Cristo watermark */}
      <img
        src={cristoAsset.url}
        alt=""
        aria-hidden
        className="pointer-events-none select-none absolute -right-20 top-1/2 -translate-y-1/2 w-[720px] max-w-none opacity-[0.06]"
      />

      <header className="relative z-10 bg-[var(--brand-navy)] text-white">
        <div className="max-w-[1100px] mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <img src={logoAsset.url} alt="Social Pass" className="h-8 w-8 object-contain" />
            <span className="font-display font-bold tracking-[0.2em] text-sm uppercase">
              Assistência Social
            </span>
          </Link>
          <Link to="/" className="text-xs flex items-center gap-1.5 text-white/80 hover:text-white transition">
            <ArrowLeft className="h-4 w-4" /> Voltar
          </Link>
        </div>
      </header>

      <main className="relative z-10 max-w-2xl mx-auto px-6 py-10">
        <div className="mb-8 text-center">
          <img src={logoAsset.url} alt="" className="h-14 w-14 mx-auto mb-3 object-contain" />
          <span className="inline-block text-xs font-semibold tracking-[0.22em] text-[var(--brand-blue)] uppercase">
            Portal do Cidadão Carioca
          </span>
          <h1 className="font-display font-extrabold text-4xl md:text-5xl text-[var(--brand-navy)] mt-2">
            Cadastro de Usuário
          </h1>
          <p className="text-muted-foreground mt-2 text-sm">
            Preencha seus dados para acessar os programas do Social Pass.
          </p>
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); }}
          className="bg-white rounded-2xl border border-border shadow-[var(--shadow-soft)] p-6 md:p-8 space-y-5"
        >
          <Field label="Nome Completo" icon={<User className="h-4 w-4" />}>
            <input required value={form.nome} onChange={set("nome")} placeholder="Como está no seu documento"
              className={inputCls} />
          </Field>

          <div className="grid md:grid-cols-2 gap-5">
            <Field label="CPF" icon={<IdCard className="h-4 w-4" />}>
              <input required inputMode="numeric" value={form.cpf}
                onChange={(e) => setForm((s) => ({ ...s, cpf: formatCpf(e.target.value) }))}
                placeholder="000.000.000-00" className={inputCls} />
            </Field>
            <Field label="Data de Nascimento" icon={<Calendar className="h-4 w-4" />}>
              <input required type="date" value={form.nascimento} onChange={set("nascimento")} className={inputCls} />
            </Field>
          </div>

          <Field label="Email" icon={<Mail className="h-4 w-4" />}>
            <input required type="email" value={form.email} onChange={set("email")}
              placeholder="voce@email.com" className={inputCls} />
          </Field>

          <Field label="Telefone" icon={<Phone className="h-4 w-4" />}>
            <input required inputMode="tel" value={form.telefone}
              onChange={(e) => setForm((s) => ({ ...s, telefone: formatPhone(e.target.value) }))}
              placeholder="(21) 99999-9999" className={inputCls} />
          </Field>

          <Field label="Criar Senha" icon={<Lock className="h-4 w-4" />}>
            <input required type={showPassword ? "text" : "password"} value={form.senha} onChange={set("senha")}
              placeholder="Mínimo 8 caracteres" minLength={8} className={inputCls + " pr-12"} />
            <button type="button" onClick={() => setShowPassword((s) => !s)}
              aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
              className="absolute right-3 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-lg text-muted-foreground hover:text-[var(--brand-navy)] hover:bg-secondary transition-colors">
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </Field>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Link to="/" className="flex-1 h-12 rounded-xl border-2 border-[var(--brand-navy)] text-[var(--brand-navy)] font-display font-bold tracking-wider text-sm uppercase flex items-center justify-center hover:bg-secondary transition">
              Cancelar
            </Link>
            <button type="submit"
              className="flex-1 h-12 rounded-xl bg-[var(--brand-navy)] text-white font-display font-bold tracking-wider text-sm uppercase shadow-[var(--shadow-elegant)] hover:bg-[var(--brand-blue)] transition">
              Cadastrar
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}

const inputCls =
  "w-full h-12 pl-11 pr-4 rounded-xl bg-white border border-border text-[var(--brand-navy)] placeholder:text-muted-foreground focus:outline-none focus:border-[var(--brand-blue)] focus:ring-4 focus:ring-[var(--brand-blue)]/15 transition-all";

function Field({ label, icon, children }: { label: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-[var(--brand-navy)] mb-2 tracking-wide uppercase">
        {label}
      </label>
      <div className="relative">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</span>
        {children}
      </div>
    </div>
  );
}
